import xmlrpc.client

server = xmlrpc.client.ServerProxy("http://13.62.52.159:8000/")

print("Add Result:", server.add(10, 5))
print("Subtract Result:", server.subtract(10, 5))
