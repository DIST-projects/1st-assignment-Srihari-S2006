import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorServer extends UnicastRemoteObject implements Calculator {

    protected CalculatorServer() throws Exception {
        super();
    }

    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public static void main(String[] args) {
        try {
            System.setProperty("java.rmi.server.hostname", "13.62.52.159");

            LocateRegistry.createRegistry(1099);

            CalculatorServer server = new CalculatorServer();
            Naming.rebind("CalculatorService", server);

            System.out.println("✅ RMI Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
