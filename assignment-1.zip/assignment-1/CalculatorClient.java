import java.rmi.Naming;

public class CalculatorClient {
    public static void main(String[] args) {
        try {
            Calculator c = (Calculator) Naming.lookup(
                "rmi://13.62.52.159:1099/CalculatorService"
            );

            System.out.println("Add: " + c.add(10, 5));
            System.out.println("Sub: " + c.subtract(10, 5));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
